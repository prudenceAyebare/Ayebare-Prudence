% Brent's Method (fzero) - Projectile Motion
clear; clc;

fprintf('=== BRENT''S METHOD: Projectile Motion ===\n');
fprintf('Solving h(t) = -4.9t² + 15t + 10 = 0\n');
fprintf('Using MATLAB''s fzero (implements Brent''s method)\n\n');

% Same function as before
f = @(t) -4.9*t.^2 + 15*t + 10;

% Method 1: Using initial guess
fprintf('Method 1: Using initial guess t0 = 3.0\n');
t0 = 3.0;
tic;
[t_root1, fval1, exitflag1, output1] = fzero(f, t0);
computation_time1 = toc;

fprintf('Root found: t = %.8f seconds\n', t_root1);
fprintf('Function value at root: f(t) = %.2e\n', fval1);
fprintf('Exit flag: %d ', exitflag1);
if exitflag1 == 1
    fprintf('(Successfully converged)\n');
else
    fprintf('(Convergence issues)\n');
end
fprintf('Function evaluations: %d\n', output1.funcCount);
fprintf('Iterations: %d\n', output1.iterations);
fprintf('Computation time: %.6f seconds\n', computation_time1);

% Method 2: Using interval (bracketing)
fprintf('\nMethod 2: Using bracketing interval [2.0, 4.0]\n');
interval = [2.0, 4.0];
tic;
[t_root2, fval2, exitflag2, output2] = fzero(f, interval);
computation_time2 = toc;

fprintf('Root found: t = %.8f seconds\n', t_root2);
fprintf('Function value at root: f(t) = %.2e\n', fval2);
fprintf('Exit flag: %d ', exitflag2);
if exitflag2 == 1
    fprintf('(Successfully converged)\n');
else
    fprintf('(Convergence issues)\n');
end
fprintf('Function evaluations: %d\n', output2.funcCount);
fprintf('Iterations: %d\n', output2.iterations);
fprintf('Computation time: %.6f seconds\n', computation_time2);

% Comparison with previous methods
fprintf('\n=== COMPARISON WITH OTHER METHODS ===\n');
fprintf('Brent''s Method:     t = %.8f seconds (%d iterations)\n', t_root1, output1.iterations);
fprintf('Newton-Raphson:     t = 3.032771 seconds (3-4 iterations)\n');
fprintf('Secant Method:      t = 3.032771 seconds (3-4 iterations)\n');
fprintf('Bisection Method:   t = 3.756500 seconds (15-20 iterations)\n');

% Visualization
figure;
t_range = linspace(0, 5, 1000);
plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
hold on;
plot(t_root1, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Time t (seconds)');
ylabel('Height h(t) (meters)');
title('Brent''s Method: Projectile Motion');
legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Location', 'northeast');
grid on;

% Brent's Method (fzero) - Ideal Gas Volume

fprintf('=== BRENT''S METHOD: Ideal Gas Volume ===\n');
fprintf('Solving f(V) = V³ - 0.165V² + 0.000136 = 0\n');
fprintf('Using MATLAB''s fzero (implements Brent''s method)\n\n');

% Same function as before
f = @(V) V.^3 - 0.165*V.^2 + 0.000136;

% Method 1: Using initial guess
fprintf('Method 1: Using initial guess V0 = 0.15\n');
V0 = 0.15;
tic;
[V_root1, fval1, exitflag1, output1] = fzero(f, V0);
computation_time1 = toc;

fprintf('Root found: V = %.8f m³/mol\n', V_root1);
fprintf('Function value at root: f(V) = %.2e\n', fval1);
fprintf('Exit flag: %d ', exitflag1);
if exitflag1 == 1
    fprintf('(Successfully converged)\n');
else
    fprintf('(Convergence issues)\n');
end
fprintf('Function evaluations: %d\n', output1.funcCount);
fprintf('Iterations: %d\n', output1.iterations);
fprintf('Computation time: %.6f seconds\n', computation_time1);

% Method 2: Using interval (bracketing)
fprintf('\nMethod 2: Using bracketing interval [0.1, 0.2]\n');
interval = [0.1, 0.2];
tic;
[V_root2, fval2, exitflag2, output2] = fzero(f, interval);
computation_time2 = toc;

fprintf('Root found: V = %.8f m³/mol\n', V_root2);
fprintf('Function value at root: f(V) = %.2e\n', fval2);
fprintf('Exit flag: %d ', exitflag2);
if exitflag2 == 1
    fprintf('(Successfully converged)\n');
else
    fprintf('(Convergence issues)\n');
end
fprintf('Function evaluations: %d\n', output2.funcCount);
fprintf('Iterations: %d\n', output2.iterations);
fprintf('Computation time: %.6f seconds\n', computation_time2);


% Visualization
figure;
V_range = linspace(0.1, 0.2, 1000);
plot(V_range, f(V_range), 'b-', 'LineWidth', 2);
hold on;
plot(V_root1, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([0.1, 0.2], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Volume V (m³/mol)');
ylabel('f(V)');
title('Brent''s Method: Gas Volume');
legend('f(V) = V³ - 0.165V² + 0.000136', 'Root Found', 'Location', 'northwest');
grid on;