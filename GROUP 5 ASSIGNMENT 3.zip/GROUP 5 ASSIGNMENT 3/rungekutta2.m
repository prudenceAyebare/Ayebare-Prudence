% Runge-Kutta 4th Order - Projectile Motion
clear; clc;

fprintf('=== RUNGE-KUTTA 4th ORDER: Projectile Motion ===\n');
fprintf('Solving projectile motion with air resistance using RK4\n\n');

% System parameters
m = 0.5;        % Mass of projectile (kg)
g = 9.81;       % Gravity (m/s²)
c = 0.001;      % Drag coefficient
A = 0.01;       % Cross-sectional area (m²)
rho = 1.225;    % Air density (kg/m³)

% Initial conditions (launch at 45 degrees)
v0 = 50;        % Initial velocity (m/s)
theta = 45;     % Launch angle (degrees)
x0 = 0;         % Initial x-position (m)
y0 = 0;         % Initial y-position (m)

% Convert angle to radians
theta_rad = theta * pi / 180;

% Initial velocity components
vx0 = v0 * cos(theta_rad);
vy0 = v0 * sin(theta_rad);

% Time parameters
t_start = 0;
t_end = 10;     % 10 seconds simulation
h = 0.01;       % Step size
N = round((t_end - t_start) / h);

fprintf('System Parameters:\n');
fprintf('Mass: m = %.1f kg\n', m);
fprintf('Initial velocity: v0 = %d m/s\n', v0);
fprintf('Launch angle: θ = %d degrees\n', theta);
fprintf('Step size: h = %.3f s\n', h);
fprintf('Number of steps: N = %d\n\n', N);

% Initialize arrays
t = zeros(1, N+1);
x = zeros(1, N+1);     % x-position
y = zeros(1, N+1);     % y-position
vx = zeros(1, N+1);    % x-velocity
vy = zeros(1, N+1);    % y-velocity

% Set initial conditions
t(1) = t_start;
x(1) = x0;
y(1) = y0;
vx(1) = vx0;
vy(1) = vy0;

% RK4 Method Implementation
fprintf('Running RK4 method...\n');
for n = 1:N
    % Current state vector [x; y; vx; vy]
    Y = [x(n); y(n); vx(n); vy(n)];
    
    % RK4 slope calculations
    k1 = h * projectile_derivatives(Y, m, g, c, A, rho);
    k2 = h * projectile_derivatives(Y + 0.5*k1, m, g, c, A, rho);
    k3 = h * projectile_derivatives(Y + 0.5*k2, m, g, c, A, rho);
    k4 = h * projectile_derivatives(Y + k3, m, g, c, A, rho);
    
    % RK4 update
    Y_new = Y + (k1 + 2*k2 + 2*k3 + k4) / 6;
    
    % Store results
    x(n+1) = Y_new(1);
    y(n+1) = Y_new(2);
    vx(n+1) = Y_new(3);
    vy(n+1) = Y_new(4);
    t(n+1) = t(n) + h;
    
    % Stop if projectile hits ground
    if y(n+1) < 0
        y(n+1) = 0;
        break;
    end
end

% Trim arrays to actual simulation length
t = t(1:n+1);
x = x(1:n+1);
y = y(1:n+1);
vx = vx(1:n+1);
vy = vy(1:n+1);

% Calculate performance metrics
range = x(end);  % Final x-position when hitting ground
max_height = max(y);
flight_time = t(end);

fprintf('RK4 Results:\n');
fprintf('Maximum height: %.2f m\n', max_height);
fprintf('Range: %.2f m\n', range);
fprintf('Flight time: %.2f seconds\n', flight_time);

% Plot trajectory
figure;
plot(x, y, 'r-', 'LineWidth', 2);
xlabel('Horizontal Distance (meters)');
ylabel('Height (meters)');
title('RK4 Method: Projectile Trajectory with Air Resistance');
grid on;

fprintf('Projectile simulation completed successfully!\n');

% Derivative function for projectile motion
function dYdt = projectile_derivatives(Y, m, g, c, A, rho)
    % Y = [x; y; vx; vy]
    % dYdt = [vx; vy; ax; ay]
    x_pos = Y(1);
    y_pos = Y(2);
    v_x = Y(3);
    v_y = Y(4);
    
    % Calculate speed
    speed = sqrt(v_x^2 + v_y^2);
    
    % Drag force (proportional to v²)
    drag_force = 0.5 * c * A * rho * speed^2;
    
    % Drag force components (opposes motion)
    if speed > 0
        drag_x = -drag_force * (v_x / speed);
        drag_y = -drag_force * (v_y / speed);
    else
        drag_x = 0;
        drag_y = 0;
    end
    
    % Acceleration components
    ax = drag_x / m;
    ay = -g + (drag_y / m);
    
    dYdt = zeros(4,1);
    dYdt(1) = v_x;    % dx/dt = vx
    dYdt(2) = v_y;    % dy/dt = vy
    dYdt(3) = ax;     % dvx/dt = ax
    dYdt(4) = ay;     % dvy/dt = ay
end