% Newton-Raphson Method - Projectile Motion (Same as Bisection)
clear; clc;

fprintf('=== NEWTON-RAPHSON: Projectile Motion ===\n');
fprintf('Solving h(t) = -4.9t² + 15t + 10 = 0\n');
fprintf('Same problem as bisection method for comparison\n\n');

% Same function as bisection method
f = @(t) -4.9*t.^2 + 15*t + 10;

% Derivative needed for Newton-Raphson
df = @(t) -9.8*t + 15;

% Parameters (same tolerance for fair comparison)
t0 = 2.5;       % Initial guess (different from bisection's interval)
tol = 1e-6;
max_iter = 20;

fprintf('Iter\t  t_n\t\t  f(t_n)\t\t  f''(t_n)\t  t_{n+1}\t  Error\n');
fprintf('----\t---------\t---------\t---------\t---------\t----------\n');

t = t0;
for iter = 1:max_iter
    ft = f(t);
    dft = df(t);
    
    t_new = t - ft/dft;
    error_est = abs(t_new - t);
    
    fprintf('%3d\t%8.6f\t%9.6f\t%9.6f\t%8.6f\t%10.2e\n', ...
            iter, t, ft, dft, t_new, error_est);
    
    if abs(ft) < tol || error_est < tol
        fprintf('\n✓ Converged to root: t = %.8f seconds\n', t_new);
        fprintf('✓ f(t) at root = %.2e\n', f(t_new));
        fprintf('✓ Iterations: %d\n', iter);
        
        % Compare with bisection result (approximately 3.7565)
        bisection_result = 3.7565;
 fprintf('✓ Bisection result: t = %.4f seconds\n', bisection_result);
        fprintf('✓ Difference: %.6f seconds\n', abs(t_new - bisection_result));
        break;
    end
    
    t = t_new;
    
    if iter == max_iter
        fprintf('\n! Maximum iterations reached.\n');
    end
end

% Visualization
figure;
t_range = linspace(0, 5, 1000);
plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
hold on;
plot(t_new, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Time t (seconds)');
ylabel('Height h(t) (meters)');
title('Newton-Raphson: Projectile Motion (Same as Bisection)');
legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Location', 'northeast');
grid on;

% Newton-Raphson Method - Ideal Gas Volume (Same as Bisection)
clear; clc;

fprintf('=== NEWTON-RAPHSON: Ideal Gas Volume ===\n');
fprintf('Solving f(V) = V³ - 0.165V² + 0.000136 = 0\n');
fprintf('Same problem as bisection method for comparison\n\n');

% Same function as bisection method
f = @(V) V.^3 - 0.165*V.^2 + 0.000136;
% Derivative needed for Newton-Raphson
df = @(V) 3*V.^2 - 0.33*V;

% Parameters (same tolerance for fair comparison)
V0 = 0.15;      % Initial guess (within bisection interval [0.1, 0.2])
tol = 1e-6;
max_iter = 20;

fprintf('Iter\t  V_n\t\t  f(V_n)\t\t  f''(V_n)\t  V_{n+1}\t  Error\n');
fprintf('----\t---------\t---------\t---------\t---------\t----------\n');

V = V0;
for iter = 1:max_iter
    fV = f(V);
    dfV = df(V);
    
    V_new = V - fV/dfV;
    error_est = abs(V_new - V);
    
    fprintf('%3d\t%8.6f\t%10.2e\t%10.2e\t%8.6f\t%10.2e\n', ...
            iter, V, fV, dfV, V_new, error_est);
    
    if abs(fV) < tol || error_est < tol
        fprintf('\n✓ Converged to root: V = %.8f m³/mol\n', V_new);
        fprintf('✓ f(V) at root = %.2e\n', f(V_new));
        fprintf('✓ Iterations: %d\n', iter);
        
        % Compare with bisection result (approximately 0.16499999)
        bisection_result = 0.16499999;
        fprintf('✓ Bisection result: V = %.8f m³/mol\n', bisection_result);
        fprintf('✓ Difference: %.2e m³/mol\n', abs(V_new - bisection_result));
        break;
    end
    
 V = V_new;
    
    if iter == max_iter
        fprintf('\n! Maximum iterations reached.\n');
    end
end

% Visualization
figure;
V_range = linspace(0.1, 0.2, 1000);
plot(V_range, f(V_range), 'b-', 'LineWidth', 2);
hold on;
plot(V_new, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([0.1, 0.2], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Volume V (m³/mol)');
ylabel('f(V)');
title('Newton-Raphson: Gas Volume (Same as Bisection)');
legend('f(V) = V³ - 0.165V² + 0.000136', 'Root Found', 'Location', 'northwest');
grid on;