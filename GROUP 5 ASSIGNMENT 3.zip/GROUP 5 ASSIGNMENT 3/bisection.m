% Bisection Method - Projectile Height Problem
clear; clc;

fprintf('=== PROBLEM 1: Projectile Height ===\n');
fprintf('Find when projectile hits ground: f(t) = -4.9t² + 15t + 10 = 0\n\n');

% Define function and parameters
f = @(t) -4.9*t.^2 + 15*t + 10;
a = 0; b = 5;  % Time between 0 and 5 seconds
tol = 1e-4; max_iter = 50;

% Verify root exists
if f(a)*f(b) > 0
    error('No root in interval! Adjust a and b.');
end

% Bisection algorithm
fprintf('Iter\t  a\t\t  b\t\t  c\t\t  f(c)\n');
fprintf('----\t-----\t-----\t-----\t---------\n');

for iter = 1:max_iter
    c = (a + b) / 2;
    fc = f(c);
    
    fprintf('%3d\t%6.3f\t%6.3f\t%6.3f\t%8.4f\n', iter, a, b, c, fc);
    
    if abs(fc) < tol
        fprintf('\n✓ Projectile hits ground at t = %.4f seconds\n', c);
        fprintf('✓ Height at impact: f(t) = %.6f meters\n', fc);
        fprintf('✓ Iterations: %d\n', iter);
        break;
    end
    
    if f(a)*fc < 0, b = c; else, a = c; end
    
    if iter == max_iter
        fprintf('\n! Max iterations reached. t ≈ %.4f seconds\n', c);
    end
end
% Visualization
figure;
t = linspace(0, 5, 100);
h = f(t);
plot(t, h, 'b-', 'LineWidth', 2);
hold on;
plot(c, fc, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'red');
plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Time (seconds)');
ylabel('Height (meters)');
title('Projectile Height vs Time');
legend('Height', 'Impact Point', 'Ground Level', 'Location', 'northeast');
grid on;

% Bisection Method - Ideal Gas Volume Problem

fprintf('=== PROBLEM 2: Ideal Gas Volume ===\n');
fprintf('Find volume where pressure is zero: f(V) = V³ - 0.165V² + 0.000136 = 0\n\n');

% Define function and parameters
f = @(V) V.^3 - 0.165*V.^2 + 0.000136;
a = 0.1; b = 0.2;  % Volume between 0.1 and 0.2 m³/mol
tol = 1e-6; max_iter = 50;

% Verify root exists
if f(a)*f(b) > 0
    error('No root in interval! Adjust a and b.');
end

% Bisection algorithm
fprintf('Iter\t  a\t\t  b\t\t  c\t\t  f(c)\n');
fprintf('----\t-----\t-----\t-----\t---------\n');

for iter = 1:max_iter
c = (a + b) / 2;
    fc = f(c);
    
    fprintf('%3d\t%8.6f\t%8.6f\t%8.6f\t%10.2e\n', iter, a, b, c, fc);
    
    if abs(fc) < tol
        fprintf('\n✓ Zero-pressure volume: V = %.8f m³/mol\n', c);
        fprintf('✓ Function value: f(V) = %.2e\n', fc);
        fprintf('✓ Iterations: %d\n', iter);
        break;
    end
    
    if f(a)*fc < 0, b = c; else, a = c; end
    
    if iter == max_iter
        fprintf('\n! Max iterations reached. V ≈ %.8f m³/mol\n', c);
    end
end

% Visualization
figure;
V = linspace(0.1, 0.2, 100);
P = f(V);
plot(V, P, 'b-', 'LineWidth', 2);
hold on;
plot(c, fc, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'red');
plot([0.1, 0.2], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Volume V (m³/mol)');
ylabel('f(V)');
title('Gas Equation Root Finding');
legend('f(V) = V³ - 0.165V² + 0.000136', 'Root', 'Zero Line', 'Location', 'northwest');
grid on;