% Secant Method - Projectile Motion
clear; clc;

fprintf('=== SECANT METHOD: Projectile Motion ===\n');
fprintf('Solving h(t) = -4.9t² + 15t + 10 = 0\n');
fprintf('Same problem as bisection and Newton-Raphson\n\n');

% Same function as before
f = @(t) -4.9*t.^2 + 15*t + 10;

% Parameters - need TWO initial guesses
t0 = 2.0;       % First initial guess
t1 = 4.0;       % Second initial guess
tol = 1e-6;
max_iter = 20;

fprintf('Initial guesses: t0 = %.1f, t1 = %.1f seconds\n', t0, t1);
fprintf('Iter\t  t_{n-1}\t  t_n\t\t  f(t_{n-1})\t  f(t_n)\t  t_{n+1}\t  Error\n');
fprintf('----\t---------\t---------\t---------\t---------\t---------\t----------\n');

t_prev = t0;
t_curr = t1;
f_prev = f(t_prev);

for iter = 1:max_iter
    f_curr = f(t_curr);
    
    % Secant formula: x_{n+1} = x_n - f(x_n) * (x_n - x_{n-1}) / (f(x_n) - f(x_{n-1}))
    if abs(f_curr - f_prev) < 1e-12
        fprintf('Function values too close - method may fail\n');
        break;
    end
    
    t_next = t_curr - f_curr * (t_curr - t_prev) / (f_curr - f_prev);
    error_est = abs(t_next - t_curr);
    
 fprintf('%3d\t%8.6f\t%8.6f\t%9.6f\t%9.6f\t%8.6f\t%10.2e\n', ...
            iter, t_prev, t_curr, f_prev, f_curr, t_next, error_est);
    
    if abs(f_curr) < tol || error_est < tol
        fprintf('\n✓ Converged to root: t = %.8f seconds\n', t_next);
        fprintf('✓ f(t) at root = %.2e\n', f(t_next));
        fprintf('✓ Iterations: %d\n', iter);
        
        % Compare with previous methods
        newton_result = 3.032771;  % From Newton-Raphson
        bisection_result = 3.7565;  % From Bisection
        fprintf('✓ Newton-Raphson result: t = %.6f seconds\n', newton_result);
        fprintf('✓ Bisection result: t = %.4f seconds\n', bisection_result);
        break;
    end
    
    % Update for next iteration
    t_prev = t_curr;
    f_prev = f_curr;
    t_curr = t_next;
    
    if iter == max_iter
        fprintf('\n! Maximum iterations reached.\n');
    end
end

% Visualization
figure;
t_range = linspace(0, 5, 1000);
plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
hold on;
plot(t_next, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([t0, t1], [f(t0), f(t1)], 'g--', 'LineWidth', 1); % Initial secant
plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Time t (seconds)');
ylabel('Height h(t) (meters)');
title('Secant Method: Projectile Motion');
legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Initial Secant', 'Location', 'northeast');
grid on;

% Secant Method - Ideal Gas Volume

fprintf('=== SECANT METHOD: Ideal Gas Volume ===\n');
fprintf('Solving f(V) = V³ - 0.165V² + 0.000136 = 0\n');
fprintf('Same problem as bisection and Newton-Raphson\n\n');

% Same function as before
f = @(V) V.^3 - 0.165*V.^2 + 0.000136;

% Parameters - need TWO initial guesses
V0 = 0.1;       % First initial guess
V1 = 0.2;       % Second initial guess (bracketing the root)
tol = 1e-6;
max_iter = 20;

fprintf('Initial guesses: V0 = %.1f, V1 = %.1f m³/mol\n', V0, V1);
fprintf('Iter\t  V_{n-1}\t  V_n\t\t  f(V_{n-1})\t  f(V_n)\t  V_{n+1}\t  Error\n');
fprintf('----\t---------\t---------\t---------\t---------\t---------\t----------\n');

V_prev = V0;
V_curr = V1;
f_prev = f(V_prev);

for iter = 1:max_iter
    f_curr = f(V_curr);
 % Secant formula
    if abs(f_curr - f_prev) < 1e-12
        fprintf('Function values too close - method may fail\n');
        break;
    end
    
    V_next = V_curr - f_curr * (V_curr - V_prev) / (f_curr - f_prev);
    error_est = abs(V_next - V_curr);
    
    fprintf('%3d\t%8.6f\t%8.6f\t%10.2e\t%10.2e\t%8.6f\t%10.2e\n', ...
            iter, V_prev, V_curr, f_prev, f_curr, V_next, error_est);
    
    if abs(f_curr) < tol || error_est < tol
        fprintf('\n✓ Converged to root: V = %.8f m³/mol\n', V_next);
        fprintf('✓ f(V) at root = %.2e\n', f(V_next));
        fprintf('✓ Iterations: %d\n', iter);
        
        % Compare with previous methods
        newton_result = 0.154477;     % From Newton-Raphson
        bisection_result = 0.16499999; % From Bisection
        fprintf('✓ Newton-Raphson result: V = %.8f m³/mol\n', newton_result);
        fprintf('✓ Bisection result: V = %.8f m³/mol\n', bisection_result);
        fprintf('✓ Differences: Newton: %.2e, Bisection: %.2e\n', ...
                abs(V_next - newton_result), abs(V_next - bisection_result));
        break;
    end
    
    % Update for next iteration
    V_prev = V_curr;
    f_prev = f_curr;
    V_curr = V_next;
    
    if iter == max_iter
        fprintf('\n! Maximum iterations reached.\n');
    end
end
% Visualization
figure;
V_range = linspace(0.1, 0.2, 1000);
plot(V_range, f(V_range), 'b-', 'LineWidth', 2);
hold on;
plot(V_next, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
plot([V0, V1], [f(V0), f(V1)], 'g--', 'LineWidth', 1); % Initial secant
plot([0.1, 0.2], [0, 0], 'k--', 'LineWidth', 1);
xlabel('Volume V (m³/mol)');
ylabel('f(V)');
title('Secant Method: Gas Volume');
legend('f(V) = V³ - 0.165V² + 0.000136', 'Root Found', 'Initial Secant', 'Location', 'northwest');
grid on;