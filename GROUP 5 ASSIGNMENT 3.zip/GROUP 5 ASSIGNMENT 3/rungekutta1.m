% Runge-Kutta 4th Order - Spring-Mass-Damper System
clear; clc;

fprintf('=== RUNGE-KUTTA 4th ORDER: Car Suspension System ===\n');
fprintf('Solving mÿ + cẏ + ky = 0 using RK4\n\n');

% System parameters
m = 1000;       % Mass (kg)
k = 20000;      % Spring constant (N/m)  
c = 2000;       % Damping coefficient (N·s/m)

% Initial conditions
y0 = 0.1;       % Initial displacement (m)
v0 = 0;         % Initial velocity (m/s)

% Time parameters
t_start = 0;
t_end = 5;      % 5 seconds simulation
h = 0.01;       % Step size
N = round((t_end - t_start) / h);

fprintf('System Parameters:\n');
fprintf('Mass: m = %d kg\n', m);
fprintf('Spring constant: k = %d N/m\n', k);
fprintf('Damping coefficient: c = %d N·s/m\n', c);
fprintf('Step size: h = %.3f s\n', h);
fprintf('Number of steps: N = %d\n\n', N);

% Initialize arrays
t = zeros(1, N+1);
y = zeros(1, N+1);     % Displacement
v = zeros(1, N+1);     % Velocity

% Set initial conditions
t(1) = t_start;
y(1) = y0;
v(1) = v0;

% RK4 Method Implementation
fprintf('Running RK4 method...\n');
for n = 1:N
    % Current state vector [position; velocity]
    Y = [y(n); v(n)];
    
    % RK4 slope calculations
    k1 = h * spring_mass_derivatives(Y, m, c, k);
    k2 = h * spring_mass_derivatives(Y + 0.5*k1, m, c, k);
    k3 = h * spring_mass_derivatives(Y + 0.5*k2, m, c, k);
    k4 = h * spring_mass_derivatives(Y + k3, m, c, k);
    
    % RK4 update
    Y_new = Y + (k1 + 2*k2 + 2*k3 + k4) / 6;
    
    % Store results
    y(n+1) = Y_new(1);
    v(n+1) = Y_new(2);
    t(n+1) = t(n) + h;
end

% Calculate performance metrics
[max_displacement, max_idx] = max(y);
settling_idx = find(abs(y) < 0.02, 1);
if ~isempty(settling_idx)
    settling_time = t(settling_idx);
else
    settling_time = t_end;
end

fprintf('RK4 Results:\n');
fprintf('Maximum displacement: %.6f m\n', max_displacement);
fprintf('Settling time (2%% criterion): %.3f seconds\n', settling_time);

% Plot results
figure;
plot(t, y, 'b-', 'LineWidth', 2);
xlabel('Time (seconds)');
ylabel('Displacement (meters)');
title('RK4 Method: Car Suspension Response');
grid on;

fprintf('RK4 method completed successfully!\n');

% Derivative function for spring-mass-damper system
function dYdt = spring_mass_derivatives(Y, m, c, k)
    % Y = [position; velocity]
    % dYdt = [velocity; acceleration]
    position = Y(1);
    velocity = Y(2);
    
    dYdt = zeros(2,1);
    dYdt(1) = velocity;                       % dy/dt = v
    dYdt(2) = (-c*velocity - k*position) / m; % dv/dt = (-c*v - k*y)/m
end