% Euler's Method - Spring-Mass-Damper System
clear; clc;

fprintf('=== EULER''S METHOD: Car Suspension System ===\n');
fprintf('Solving mÿ + cẏ + ky = 0 numerically\n\n');

% System parameters
m = 1000;       % Mass (kg)
k = 20000;      % Spring constant (N/m)  
c = 2000;       % Damping coefficient (N·s/m)

% Initial conditions (car hits a bump)
y0 = 0.1;       % Initial displacement (m)
v0 = 0;         % Initial velocity (m/s)

% Time parameters
t_start = 0;
t_end = 5;      % 5 seconds simulation
h = 0.01;       % Step size = 10ms
N = round((t_end - t_start) / h);

fprintf('System Parameters:\n');
fprintf('Mass: m = %d kg\n', m);
fprintf('Spring constant: k = %d N/m\n', k);
fprintf('Damping coefficient: c = %d N·s/m\n', c);
fprintf('Step size: h = %.3f s\n', h);
fprintf('Number of steps: N = %d\n\n', N);

% Initialize arrays
t = zeros(1, N+1);
y = zeros(1, N+1);     % Displacement array
v = zeros(1, N+1);     % Velocity array

% Set initial conditions
t(1) = t_start;
y(1) = y0;
v(1) = v0;

% Euler's Method Implementation
fprintf('Running Euler''s method...\n');
for n = 1:N
    % Calculate derivatives
    dydt = v(n);                            % dy/dt = velocity
    dvdt = (-c*v(n) - k*y(n)) / m;          % dv/dt = acceleration
    
    % Euler update
    y(n+1) = y(n) + h * dydt;
    v(n+1) = v(n) + h * dvdt;
    t(n+1) = t(n) + h;
end

% Calculate performance metrics
[max_displacement, max_idx] = max(y);
settling_idx = find(abs(y) < 0.02, 1);
if ~isempty(settling_idx)
    settling_time = t(settling_idx);
else
    settling_time = t_end;
end

fprintf('Numerical Results:\n');
fprintf('Maximum displacement: %.4f m\n', max_displacement);
fprintf('Settling time (2%% criterion): %.2f seconds\n', settling_time);

% Single main plot
figure;
plot(t, y, 'b-', 'LineWidth', 2);
xlabel('Time (seconds)');
ylabel('Displacement (meters)');
title('Euler''s Method: Car Suspension Response');
grid on;

fprintf('Euler''s method completed successfully!\n');

% Euler's Method - Free Fall with Air Resistance

fprintf('=== EULER''S METHOD: Free Fall with Air Resistance ===\n');
fprintf('Solving vertical motion with drag force\n\n');

% System parameters
m = 80;         % Mass of person (kg)
g = 9.81;       % Gravity (m/s²)
c = 0.24;       % Drag coefficient (skydiver)
A = 0.7;        % Cross-sectional area (m²)
rho = 1.225;    % Air density (kg/m³)

% Initial conditions (jump from plane)
y0 = 3000;      % Initial height (m)
v0 = 0;         % Initial velocity (m/s)

% Time parameters
t_start = 0;
t_end = 60;     % 60 seconds simulation
h = 0.1;        % Step size = 0.1s
N = round((t_end - t_start) / h);

fprintf('System Parameters:\n');
fprintf('Mass: m = %d kg\n', m);
fprintf('Drag coefficient: c = %.2f\n', c);
fprintf('Cross-sectional area: A = %.1f m²\n', A);
fprintf('Initial height: %.0f m\n', y0);
fprintf('Step size: h = %.1f s\n', h);
fprintf('Number of steps: N = %d\n\n', N);

% Initialize arrays
t = zeros(1, N+1);
y = zeros(1, N+1);     % Height array
v = zeros(1, N+1);     % Velocity array

% Set initial conditions
t(1) = t_start;
y(1) = y0;
v(1) = v0;

% Euler's Method Implementation
fprintf('Running Euler''s method...\n');
for n = 1:N
    % Calculate forces
    drag_force = 0.5 * c * A * rho * v(n)^2;  % Air resistance
    if v(n) > 0
        drag_force = -drag_force;  % Drag opposes motion
    end
    
    % Calculate acceleration (Newton's 2nd law)
    acceleration = (m*g + drag_force) / m;
    
    % Euler update
    v(n+1) = v(n) + h * acceleration;
    y(n+1) = y(n) + h * v(n);
    t(n+1) = t(n) + h;
    
    % Stop if object hits ground
    if y(n+1) <= 0
        y(n+1) = 0;
        v(n+1) = 0;
        break;
    end
end

% Trim arrays to actual simulation length
t = t(1:n+1);
y = y(1:n+1);
v = v(1:n+1);

% Calculate performance metrics
terminal_velocity = abs(min(v));
time_to_ground = t(end);

fprintf('Numerical Results:\n');
fprintf('Terminal velocity: %.2f m/s\n', terminal_velocity);
fprintf('Time to reach ground: %.2f seconds\n', time_to_ground);
fprintf('Final impact velocity: %.2f m/s\n', abs(v(end)));

% Single main plot
figure;
plot(t, y, 'r-', 'LineWidth', 2);
xlabel('Time (seconds)');
ylabel('Height (meters)');
title('Euler''s Method: Free Fall with Air Resistance');
grid on;
fprintf('Free fall simulation completed successfully!\n');