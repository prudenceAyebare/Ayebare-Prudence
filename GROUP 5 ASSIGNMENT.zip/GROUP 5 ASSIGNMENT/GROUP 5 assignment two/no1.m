data2010 = readtable('C:\Users\hp\Desktop\GROUP 5 ASSIGNMENT\GROUP 5 assignment 1\life.xlsx', 'Sheet', '2010');
scatter(data2010.GDP, data2010.Life_expectancy, "filled");
xlabel("GDP")
ylabel("Life Expectancy")
title("Life Expectancy vs GDP 2010")
grid on
saveas(gcf, 'life_expectancy_vs_gdp_2010.png')

data2014 = readtable('C:\Users\hp\Desktop\GROUP 5 ASSIGNMENT\GROUP 5 assignment 1\life.xlsx','Sheet','2014');
%Define East African countries
eastAfrica = {'Uganda','Burundi','Kenya','Rwanda'};

% filtering the rows
isEastAfrica = ismember(data2014.Country,eastAfrica);
eastAfricaData = data2014(isEastAfrica,:);

%the bar graph
bar(categorical(eastAfricaData.Country),eastAfricaData.Population);
xlabel('Country')
ylabel('population')
title('Population of African countries in est africa - 2014')
grid on
saveas(gcf, 'EastAfrica_Population_2014.png')

if ~isnumeric(eastAfricaData.Population)
    eastAfricaData.Population = str2double(eastAfricaData.Population);
end

% Extract population
populations = eastAfricaData.Population;

% Calculate statistics
meanPop = mean(populations, 'omitnan');
medianPop = median(populations, 'omitnan');
stdPop = std(populations, 'omitnan');
minPop = min(populations);
maxPop = max(populations);

% Display results
fprintf('----Statistics of the East African Popultion---\n');
fprintf('Mean population: %.0f\n', meanPop);
fprintf('Median population: %.0f\n', medianPop);
fprintf('Standard deviation: %.0f\n', stdPop);
fprintf('Minimum population: %.0f\n', minPop);
fprintf('Maximum population: %.0f\n', maxPop);

%Reading data from 2008, sheet alcohol consumption with east african
%countries.
% Read 2014 data
data2008 = readtable('C:\Users\hp\Desktop\GROUP 5 ASSIGNMENT\GROUP 5 assignment 1\life.xlsx', 'Sheet', '2008', 'VariableNamingRule', 'modify');

% East African countries
eastAfrica = {'Uganda', 'United Republic of Tanzania', 'Rwanda', 'Kenya'};

% Filter rows for East African countries
isEastAfrica = ismember(data2008.Country, eastAfrica);
eastAfricaData = data2008(isEastAfrica, :);

% Convert Alcohol data to numeric if needed
if ~isnumeric(eastAfricaData.Alcohol)
    eastAfricaData.Alcohol = str2double(eastAfricaData.Alcohol);
end

% Extract Alcohol consumption and countries
alcoholConsumption = eastAfricaData.Alcohol;
countries = eastAfricaData.Country;

% Plot pie chart
figure
pie(alcoholConsumption, countries)
title('Alcohol Consumption in East African Countries (2008)')

% Save image
saveas(gcf, 'EastAfrica_Alcohol_Pie_2014.png')

%obtain the data
data2012 = readtable('C:\Users\hp\Desktop\GROUP 5 ASSIGNMENT\GROUP 5 assignment 1\life.xlsx', 'Sheet', '2012','VariableNamingRule','modify');
numericData= data2012(:,{'Life_expectancy', 'AdultMortality', 'Alcohol';
    'GDP', 'Population', 'infantDeaths'});
% Convert table to matrix
dataMatrix = table2array(numericData);
% Compute correlation matrix
corrMatrix = corr(dataMatrix, 'Rows', 'complete');
% Plot heatmap
heatmap(corrMatrix, ...
    'XDisplayLabels', numericData.Properties.VariableNames, ...
    'YDisplayLabels', numericData.Properties.VariableNames, ...
    'Title', 'Correlation Heatmap');
saveas(gcf, 'HeatMap_2012.png')

% Load the 2003 data
data2003 = readtable('C:\Users\hp\Desktop\GROUP 5 ASSIGNMENT\GROUP 5 assignment 1\life.xlsx', 'Sheet', '2003', 'VariableNamingRule','modify');

% Extract relevant columns
GDP = data2003.GDP;
Alcohol = data2003.Alcohol;
LifeExp = data2003.Life_expectancy;

% 3D Scatter plot
figure;
scatter3(GDP, Alcohol, LifeExp, 50, LifeExp, 'filled');
xlabel('GDP');
ylabel('Alcohol Consumption');
zlabel('Life Expectancy');
title('3D Plot: Life Expectancy vs GDP and Alcohol (2003)');
colorbar;
grid on;
view(135, 30); % adjust view angle
saveas(gcf,'3D plot.png')