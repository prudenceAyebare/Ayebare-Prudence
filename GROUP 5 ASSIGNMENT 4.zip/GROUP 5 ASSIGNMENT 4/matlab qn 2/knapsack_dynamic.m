% knapsack_dynamic.m
function knapsack_dynamic()
    clc;
    
    fprintf('=== KNAPSACK PROBLEM - DYNAMIC PROGRAMMING SOLUTION ===\n\n');
    
    % Problem data
    weights = [2, 3, 4, 5];
    values = [3, 4, 5, 6];
    capacity = 5;
    
    fprintf('Knapsack Problem:\n');
    fprintf('Weights: '); fprintf('%d ', weights); fprintf('\n');
    fprintf('Values:  '); fprintf('%d ', values); fprintf('\n');
    fprintf('Capacity: %d\n\n', capacity);
    
    % Measure execution time
    tic;
    [max_value, selected_items, dp_table] = knapsack_dp_core(weights, values, capacity);
    execution_time = toc;
    
    fprintf('Dynamic Programming Solution:\n');
    fprintf('Maximum value: %d\n', max_value);
    
    % Display selected items correctly
    fprintf('Selected items: ');
    selected_indices = find(selected_items);
    if isempty(selected_indices)
        fprintf('None');
    else
        for i = 1:length(selected_indices)
            idx = selected_indices(i);
            fprintf('Item %d (w=%d, v=%d) ', idx, weights(idx), values(idx));
        end
    end
    fprintf('\n');
    
    fprintf('Total weight: %d\n', sum(weights(selected_indices)));
    fprintf('Execution time: %.6f seconds\n\n', execution_time);
    
    % Display DP table
    fprintf('DP Table:\n');
    display_dp_table(dp_table, weights, values, capacity);
    
    % Performance comparison with larger problems
    fprintf('\n=== PERFORMANCE WITH LARGER PROBLEMS ===\n\n');
    
    problem_sizes = [10, 20, 30, 40, 50];
    dp_times = zeros(1, length(problem_sizes));
    dp_values = zeros(1, length(problem_sizes));
    
    fprintf('Size\tValue\tTime (s)\n');
    fprintf('----\t-----\t--------\n');
    
    for i = 1:length(problem_sizes)
        n = problem_sizes(i);
        test_weights = randi([1, 20], 1, n);
        test_values = randi([10, 50], 1, n);
        test_capacity = round(mean(test_weights) * n * 0.6); % More realistic capacity
        
        tic;
        [test_value, ~, ~] = knapsack_dp_core(test_weights, test_values, test_capacity);
        dp_times(i) = toc;
        dp_values(i) = test_value;
        
        fprintf('%2d\t%5d\t%8.4f\n', n, test_value, dp_times(i));
    end
    
    % Plot performance
    figure;
    
    subplot(1, 2, 1);
    plot(problem_sizes, dp_values, 'b-o', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('Problem Size (number of items)');
    ylabel('Maximum Value');
    title('Knapsack DP - Maximum Value vs Problem Size');
    grid on;
    
    subplot(1, 2, 2);
    plot(problem_sizes, dp_times, 'r-s', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('Problem Size (number of items)');
    ylabel('Execution Time (seconds)');
    title('Knapsack DP - Execution Time vs Problem Size');
    grid on;
end

function [max_value, selected_items, dp] = knapsack_dp_core(weights, values, capacity)
    n = length(weights);
    
    % Initialize DP table with correct dimensions
    % dp(i, w) represents maximum value with first i items and capacity w
    dp = zeros(n + 1, capacity + 1);
    
    % Build DP table
    for i = 1:n
        for w = 0:capacity
            if weights(i) <= w
                % Maximum of:
                % 1. Include current item: value[i] + dp[i-1][w-weight[i]]
                % 2. Exclude current item: dp[i-1][w]
                dp(i + 1, w + 1) = max(values(i) + dp(i, w + 1 - weights(i)), ...
                                      dp(i, w + 1));
            else
                % Cannot include current item
                dp(i + 1, w + 1) = dp(i, w + 1);
            end
        end
    end
    
    max_value = dp(n + 1, capacity + 1);
    
    % Backtrack to find selected items - CORRECTED VERSION
    selected_items = zeros(1, n);
    w = capacity;
    
    for i = n:-1:1
        % Check if item i was included
        if dp(i + 1, w + 1) ~= dp(i, w + 1)
            selected_items(i) = 1;
            w = w - weights(i);
        end
    end
end

function display_dp_table(dp, weights, values, capacity)
    [n_rows, n_cols] = size(dp);
    n_items = n_rows - 1;
    
    fprintf('\n     ');
    for w = 0:capacity
        fprintf('%3d ', w);
    end
    fprintf('\n');
    fprintf('-----');
    for w = 0:capacity
        fprintf('----');
    end
    fprintf('\n');
    
    for i = 0:n_items
        if i == 0
            fprintf('  0 |');
        else
            fprintf('%2d |', i);
        end
        
        for w = 0:capacity
            fprintf('%3d ', dp(i + 1, w + 1));
        end
        fprintf('\n');
    end
    fprintf('\n');
end