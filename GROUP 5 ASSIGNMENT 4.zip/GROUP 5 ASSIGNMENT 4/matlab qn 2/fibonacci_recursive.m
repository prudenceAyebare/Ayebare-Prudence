% fibonacci_recursive.m
function fibonacci_recursive()
    clear; clc;
    
    fprintf('=== FIBONACCI SEQUENCE - RECURSIVE SOLUTION ===\n\n');
    
    % Test values
    n_values = [5, 10, 15, 20, 25];
    results = zeros(1, length(n_values));
    times = zeros(1, length(n_values));
    
    fprintf('Recursive Fibonacci Calculation:\n\n');
    fprintf(' n\tFibonacci\tTime (s)\n');
    fprintf('--\t---------\t--------\n');
    
    for i = 1:length(n_values)
        n = n_values(i);
        
        tic;
        fib_result = fib_recursive_core(n);
        exec_time = toc;
        
        results(i) = fib_result;
        times(i) = exec_time;
        
        fprintf('%2d\t%9d\t%8.6f\n', n, fib_result, exec_time);
    end
    
    % Plot performance
    figure;
    subplot(1, 2, 1);
    plot(n_values, results, 'r-o', 'LineWidth', 2, 'MarkerSize', 8);
    xlabel('n');
    ylabel('Fibonacci(n)');
    title('Fibonacci Values - Recursive');
    grid on;
    
    subplot(1, 2, 2);
    plot(n_values, times, 'b-s', 'LineWidth', 2, 'MarkerSize', 8);
    xlabel('n');
    ylabel('Execution Time (seconds)');
    title('Execution Time - Recursive');
    grid on;
    
    % Show recursive tree for small n
    fprintf('\n=== RECURSIVE TREE FOR FIB(5) ===\n\n');
    fib_recursive_traced(5, 0);
end

function result = fib_recursive_core(n)
    if n <= 1
        result = n;
        return;
    end
    result = fib_recursive_core(n-1) + fib_recursive_core(n-2);
end

function result = fib_recursive_traced(n, depth)
    % Helper function to show recursive calls
    indent = repmat('  ', 1, depth);
    fprintf('%sfib(%d)\n', indent, n);
    
    if n <= 1
        result = n;
        return;
    end
    
    left = fib_recursive_traced(n-1, depth + 1);
    right = fib_recursive_traced(n-2, depth + 1);
    result = left + right;
end