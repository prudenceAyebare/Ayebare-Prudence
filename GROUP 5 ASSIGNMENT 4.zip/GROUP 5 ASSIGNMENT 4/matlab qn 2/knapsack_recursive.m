% knapsack_recursive.m
function knapsack_recursive()
     clc;
    
    fprintf('=== KNAPSACK PROBLEM - RECURSIVE SOLUTION ===\n\n');
    
    % Problem data
    weights = [2, 3, 4, 5];
    values = [3, 4, 5, 6];
    capacity = 5;
    
    fprintf('Knapsack Problem:\n');
    fprintf('Weights: '); fprintf('%d ', weights); fprintf('\n');
    fprintf('Values:  '); fprintf('%d ', values); fprintf('\n');
    fprintf('Capacity: %d\n\n', capacity);
    
    % Measure execution time
    tic;
    max_value = knapsack_recursive_core(weights, values, capacity, length(weights));
    execution_time = toc;
    
    fprintf('Recursive Solution:\n');
    fprintf('Maximum value: %d\n', max_value);
    fprintf('Execution time: %.6f seconds\n', execution_time);
    
    % Additional test cases
    fprintf('\n=== TESTING DIFFERENT PROBLEM SIZES ===\n\n');
    
    test_sizes = [4, 6, 8, 10];
    times = zeros(1, length(test_sizes));
    
    for i = 1:length(test_sizes)
        n = test_sizes(i);
        test_weights = randi([1, 10], 1, n);
        test_values = randi([5, 20], 1, n);
        test_capacity = round(sum(test_weights) * 0.6);
        
        tic;
        test_result = knapsack_recursive_core(test_weights, test_values, test_capacity, n);
        times(i) = toc;
        
        fprintf('Size %2d: Value = %3d, Time = %.4f seconds\n', ...
                n, test_result, times(i));
    end
    
    % Plot performance
    figure;
    plot(test_sizes, times, 'r-o', 'LineWidth', 2, 'MarkerSize', 8);
    xlabel('Problem Size (number of items)');
    ylabel('Execution Time (seconds)');
    title('Knapsack Recursive - Performance Scaling');
    grid on;
end

function max_value = knapsack_recursive_core(weights, values, capacity, n)
    % Base case: no items or no capacity
    if n == 0 || capacity == 0
        max_value = 0;
        return;
    end
    
    % If weight of nth item is more than capacity, skip it
    if weights(n) > capacity
        max_value = knapsack_recursive_core(weights, values, capacity, n-1);
        return;
    end
    
    % Return maximum of two cases:
    % (1) nth item included
    % (2) nth item not included
    include_value = values(n) + knapsack_recursive_core(weights, values, ...
                       capacity - weights(n), n-1);
    exclude_value = knapsack_recursive_core(weights, values, capacity, n-1);
    
    max_value = max(include_value, exclude_value);
end