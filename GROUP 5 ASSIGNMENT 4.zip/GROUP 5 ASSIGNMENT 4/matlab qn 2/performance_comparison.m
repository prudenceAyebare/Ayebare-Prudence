% performance_comparison_simple.m
function performance_comparison_simple()
    clc;
    
    fprintf('=== DYNAMIC PROGRAMMING PERFORMANCE COMPARISON ===\n\n');
    
    fprintf('Testing two classic problems:\n');
    fprintf('1. Knapsack Problem\n');
    fprintf('2. Fibonacci Sequence\n\n');
    
    % Test Knapsack Problem
    test_knapsack();
    
    fprintf('\n');
    
    % Test Fibonacci Sequence
    test_fibonacci();
    
    fprintf('\n=== SUMMARY ===\n');
    fprintf('Dynamic Programming is much faster than plain recursion!\n');
    fprintf('This is because DP stores results to avoid repeated calculations.\n');
end

function test_knapsack()
    fprintf('KNAPSACK PROBLEM:\n');
    fprintf('-----------------\n');
    
    % Smaller problem sizes for demonstration
    problem_sizes = [4, 6, 8, 10];
    
    for i = 1:length(problem_sizes)
        n = problem_sizes(i);
        
        % Create random problem
        weights = randi([1, 10], 1, n);
        values = randi([5, 20], 1, n);
        capacity = round(sum(weights) * 0.6);
        
        fprintf('\nProblem with %d items:\n', n);
        
        % Try recursive (only for small problems)
        if n <= 8
            try
                tic;
                rec_result = knapsack_recursive_simple(weights, values, capacity, n);
                rec_time = toc;
                fprintf('  Recursive: %d (%.4f s)\n', rec_result, rec_time);
            catch
                fprintf('  Recursive: Too slow\n');
                rec_time = Inf;
            end
        else
            fprintf('  Recursive: Skipped (too large)\n');
            rec_time = Inf;
        end
        
        % Dynamic Programming
        tic;
        dp_result = knapsack_dp_simple(weights, values, capacity);
        dp_time = toc;
        fprintf('  DP:        %d (%.4f s)\n', dp_result, dp_time);
        
        % Show speedup if both methods worked
        if rec_time < Inf && rec_time > 0
            speedup = rec_time / dp_time;
            fprintf('  Speedup: %.1f times faster\n', speedup);
        end
    end
end

function test_fibonacci()
    fprintf('\nFIBONACCI SEQUENCE:\n');
    fprintf('-------------------\n');
    
    % Test different Fibonacci numbers
    fib_numbers = [10, 15, 20, 25, 30];
    
    for i = 1:length(fib_numbers)
        n = fib_numbers(i);
        
        fprintf('\nFibonacci(%d):\n', n);
        
        % Try recursive (only for smaller n)
        if n <= 25
            try
                tic;
                rec_result = fib_recursive_simple(n);
                rec_time = toc;
                fprintf('  Recursive: %d (%.4f s)\n', rec_result, rec_time);
            catch
                fprintf('  Recursive: Too slow\n');
                rec_time = Inf;
            end
        else
            fprintf('  Recursive: Skipped (too large)\n');
            rec_time = Inf;
        end
        
        % Dynamic Programming with memoization
        tic;
        dp_result = fib_dp_simple(n);
        dp_time = toc;
        fprintf('  DP:        %d (%.4f s)\n', dp_result, dp_time);
        
        % Show speedup if both methods worked
        if rec_time < Inf && rec_time > 0
            speedup = rec_time / dp_time;
            fprintf('  Speedup: %.1f times faster\n', speedup);
        end
    end
end

% SIMPLIFIED KNAPSACK FUNCTIONS

function max_value = knapsack_recursive_simple(weights, values, capacity, n)
    % Base case: no items or no capacity
    if n == 0 || capacity == 0
        max_value = 0;
        return;
    end
    
    % If current item is too heavy, skip it
    if weights(n) > capacity
        max_value = knapsack_recursive_simple(weights, values, capacity, n-1);
        return;
    end
    
    % Try both including and excluding current item
    include_val = values(n) + knapsack_recursive_simple(weights, values, ...
                       capacity - weights(n), n-1);
    exclude_val = knapsack_recursive_simple(weights, values, capacity, n-1);
    
    max_value = max(include_val, exclude_val);
end

function max_value = knapsack_dp_simple(weights, values, capacity)
    n = length(weights);
    
    % Create DP table
    dp = zeros(n + 1, capacity + 1);
    
    % Fill the table
    for i = 1:n
        for w = 1:capacity
            if weights(i) <= w
                % Can include this item
                dp(i+1, w+1) = max(values(i) + dp(i, w+1-weights(i)), ...
                                  dp(i, w+1));
            else
                % Cannot include this item
                dp(i+1, w+1) = dp(i, w+1);
            end
        end
    end
    
    max_value = dp(n+1, capacity+1);
end

% SIMPLIFIED FIBONACCI FUNCTIONS

function result = fib_recursive_simple(n)
    if n <= 1
        result = n;
        return;
    end
    result = fib_recursive_simple(n-1) + fib_recursive_simple(n-2);
end

function result = fib_dp_simple(n)
    if n <= 1
        result = n;
        return;
    end
    
    % Create array to store Fibonacci numbers
    fib = zeros(1, n+1);
    fib(1) = 0; % fib(0)
    fib(2) = 1; % fib(1)
    
    % Build up solution
    for i = 3:n+1
        fib(i) = fib(i-1) + fib(i-2);
    end
    
    result = fib(n+1);
end