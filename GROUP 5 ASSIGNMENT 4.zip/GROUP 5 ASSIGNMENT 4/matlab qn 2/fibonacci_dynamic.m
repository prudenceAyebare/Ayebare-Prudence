% fibonacci_dynamic_simple.m
function fibonacci_dynamic_simple()
    clc;
    
    fprintf('=== FIBONACCI - DYNAMIC PROGRAMMING COMPARISON ===\n\n');
    
    % Test different Fibonacci numbers
    test_numbers = [5, 10, 15, 20, 25, 30];
    
    fprintf('Performance Comparison:\n');
    fprintf('n\tMemo\tTime(s)\tTab\tTime(s)\n');
    fprintf('--\t----\t-------\t---\t-------\n');
    
    % Test both methods
    for i = 1:length(test_numbers)
        n = test_numbers(i);
        
        % Method 1: Memoization (Top-down)
        memo_array = -1 * ones(1, n+1); % Initialize cache
        start_time = tic;
        fib_memo = fib_memo_simple(n, memo_array);
        memo_time = toc(start_time);
        
        % Method 2: Tabulation (Bottom-up) 
        start_time = tic;
        fib_tab = fib_tab_simple(n);
        tab_time = toc(start_time);
        
        % Display results
        fprintf('%d\t%d\t%.6f\t%d\t%.6f\n', ...
                n, fib_memo, memo_time, fib_tab, tab_time);
    end
    
    % Show how tabulation works for a small example
    fprintf('\n=== HOW TABULATION WORKS (for n=6) ===\n');
    show_table_simple(6);
    
    % Create simple performance plot
    plot_performance(test_numbers);
end

% MEMOIZATION APPROACH (Top-down with caching)
function result = fib_memo_simple(n, cache)
    % Base cases
    if n == 0
        result = 0;
        return;
    end
    if n == 1
        result = 1;
        return;
    end
    
    % Check if we already computed this value
    if cache(n+1) ~= -1
        result = cache(n+1);
        return;
    end
    
    % Compute and store in cache
    cache(n+1) = fib_memo_simple(n-1, cache) + fib_memo_simple(n-2, cache);
    result = cache(n+1);
end

% TABULATION APPROACH (Bottom-up iterative)
function result = fib_tab_simple(n)
    % Handle base cases
    if n == 0
        result = 0;
        return;
    end
    if n == 1
        result = 1;
        return;
    end
    
    % Create table to store results
    fib_table = zeros(1, n+1);
    fib_table(1) = 0; % fib(0)
    fib_table(2) = 1; % fib(1)
    
    % Fill table step by step
    for i = 3:n+1
        fib_table(i) = fib_table(i-1) + fib_table(i-2);
    end
    
    result = fib_table(n+1);
end

% SHOW HOW THE TABLE FILLS
function show_table_simple(n)
    fprintf('\nStep-by-step calculation:\n');
    fprintf('i:    ');
    for i = 0:n
        fprintf('%3d ', i);
    end
    fprintf('\n');
    
    fprintf('fib(i):');
    
    % Calculate and display
    if n >= 0
        fprintf('%3d ', 0); % fib(0)
    end
    if n >= 1
        fprintf('%3d ', 1); % fib(1)
    end
    
    % Calculate remaining values
    prev2 = 0; % fib(0)
    prev1 = 1; % fib(1)
    
    for i = 2:n
        current = prev1 + prev2;
        fprintf('%3d ', current);
        prev2 = prev1;
        prev1 = current;
    end
    fprintf('\n');
end

% SIMPLE PERFORMANCE PLOT
function plot_performance(n_values)
    % Calculate times for plotting
    memo_times = zeros(size(n_values));
    tab_times = zeros(size(n_values));
    
    for i = 1:length(n_values)
        n = n_values(i);
        
        % Memoization time
        memo_cache = -1 * ones(1, n+1);
        start_time = tic;
        fib_memo_simple(n, memo_cache);
        memo_times(i) = toc(start_time);
        
        % Tabulation time
        start_time = tic;
        fib_tab_simple(n);
        tab_times(i) = toc(start_time);
    end
    
    % Create plot
    figure('Position', [100, 100, 800, 400]);
    
    subplot(1, 2, 1);
    plot(n_values, memo_times, 'ro-', 'LineWidth', 2, 'MarkerSize', 6);
    hold on;
    plot(n_values, tab_times, 'bs-', 'LineWidth', 2, 'MarkerSize', 6);
    xlabel('Fibonacci Number (n)');
    ylabel('Time (seconds)');
    title('Execution Time Comparison');
    legend('Memoization', 'Tabulation', 'Location', 'northwest');
    grid on;
    
    subplot(1, 2, 2);
    bar([memo_times; tab_times]');
    xlabel('Fibonacci Number (n)');
    ylabel('Time (seconds)');
    title('Side-by-Side Comparison');
    legend('Memoization', 'Tabulation');
    grid on;
    
    fprintf('\nKey Observations:\n');
    fprintf('1. Both methods give the same Fibonacci numbers\n');
    fprintf('2. Tabulation is usually faster for larger n\n');
    fprintf('3. Memoization uses recursion (top-down)\n');
    fprintf('4. Tabulation uses iteration (bottom-up)\n');
end