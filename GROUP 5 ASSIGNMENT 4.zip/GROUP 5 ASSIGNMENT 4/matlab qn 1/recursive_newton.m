% recursive_newton.m
function recursive_newton()
    clc;
    
    fprintf('=== RECURSIVE NEWTON-RAPHSON METHOD ===\n\n');
    
    % Test function: Projectile motion
    f = @(t) -4.9*t.^2 + 15*t + 10;
    df = @(t) -9.8*t + 15;
    
    % Parameters
    x0 = 2.5;
    tol = 1e-6;
    max_iter = 20;
    
    fprintf('Solving: h(t) = -4.9t² + 15t + 10 = 0\n');
    fprintf('Initial guess: t0 = %.1f\n', x0);
    fprintf('Tolerance: %.0e\n\n', tol);
    
    fprintf('Iter\t  t_n\t\t  f(t_n)\t\t  f''(t_n)\t  Error\n');
    fprintf('----\t---------\t---------\t---------\t----------\n');
    
    % Call recursive function
    root = recursive_newton_core(f, df, x0, tol, max_iter, 1);
    
    % Visualization
    figure;
    t_range = linspace(0, 5, 1000);
    plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
    hold on;
    plot(root, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
    plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
    xlabel('Time t (seconds)');
    ylabel('Height h(t) (meters)');
    title('Recursive Newton-Raphson: Projectile Motion');
    legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Location', 'northeast');
    grid on;
    
    fprintf('\nFinal root: t = %.8f seconds\n', root);
    fprintf('Final f(t) = %.2e\n', f(root));
end

function root = recursive_newton_core(f, df, x0, tol, max_iter, current_iter)
    % Base case: maximum iterations reached
    if current_iter > max_iter
        root = x0;
        fprintf('Max iterations reached.\n');
        return;
    end
    
    fx = f(x0);
    dfx = df(x0);
    
    % Check for zero derivative
    if abs(dfx) < 1e-12
        root = x0;
        fprintf('Derivative too small. Stopping.\n');
        return;
    end
    
    % Newton-Raphson update
    x1 = x0 - fx / dfx;
    error = abs(x1 - x0);
    
    fprintf('%3d\t%8.6f\t%9.6f\t%9.6f\t%10.2e\n', ...
            current_iter, x0, fx, dfx, error);
    
    % Check convergence
    if abs(fx) < tol || error < tol
        root = x1;
        return;
    end
    
    % Recursive call
    root = recursive_newton_core(f, df, x1, tol, max_iter, current_iter + 1);
end