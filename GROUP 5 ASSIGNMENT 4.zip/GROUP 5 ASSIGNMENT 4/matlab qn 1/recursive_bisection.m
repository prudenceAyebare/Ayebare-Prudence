% recursive_bisection.m
function recursive_bisection()
     clc;
    
    fprintf('=== RECURSIVE BISECTION METHOD ===\n\n');
    
    % Test function: Projectile motion
    f = @(t) -4.9*t.^2 + 15*t + 10;
    
    % Parameters
    a = 0;
    b = 5;
    tol = 1e-6;
    max_iter = 20;
    
    fprintf('Solving: h(t) = -4.9t² + 15t + 10 = 0\n');
    fprintf('Interval: [%.1f, %.1f]\n', a, b);
    fprintf('Tolerance: %.0e\n\n', tol);
    
    % Verify root exists
    if f(a)*f(b) > 0
        error('No root in interval! Adjust a and b.');
    end
    
    % Call recursive function
    root = recursive_bisection_core(f, a, b, tol, max_iter, 1);
    
    % Visualization
    figure;
    t_range = linspace(0, 5, 1000);
    plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
    hold on;
    plot(root, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
    plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
    xlabel('Time t (seconds)');
    ylabel('Height h(t) (meters)');
    title('Recursive Bisection: Projectile Motion');
    legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Location', 'northeast');
    grid on;
    
    fprintf('\nFinal root: t = %.8f seconds\n', root);
    fprintf('Final f(t) = %.2e\n', f(root));
end

function root = recursive_bisection_core(f, a, b, tol, max_iter, current_iter)
    % Base case: maximum iterations reached
    if current_iter > max_iter
        root = (a + b) / 2;
        fprintf('Max iterations reached. Returning midpoint: %.8f\n', root);
        return;
    end
    
    % Calculate midpoint
    c = (a + b) / 2;
    fc = f(c);
    
    fprintf('Iter %2d: a=%.6f, b=%.6f, c=%.6f, f(c)=%9.6f\n', ...
            current_iter, a, b, c, fc);
    
    % Check convergence
    if abs(fc) < tol || (b - a) < tol
        root = c;
        fprintf('✓ Converged to root: %.8f\n', root);
        return;
    end
    
    % Recursive call
    if f(a) * fc < 0
        root = recursive_bisection_core(f, a, c, tol, max_iter, current_iter + 1);
    else
        root = recursive_bisection_core(f, c, b, tol, max_iter, current_iter + 1);
    end
end