% recursive_secant.m
function recursive_secant()
     clc;
    
    fprintf('=== RECURSIVE SECANT METHOD ===\n\n');
    
    % Test function: Projectile motion
    f = @(t) -4.9*t.^2 + 15*t + 10;
    
    % Parameters
    x0 = 2.0;
    x1 = 4.0;
    tol = 1e-6;
    max_iter = 20;
    
    fprintf('Solving: h(t) = -4.9t² + 15t + 10 = 0\n');
    fprintf('Initial guesses: t0 = %.1f, t1 = %.1f\n', x0, x1);
    fprintf('Tolerance: %.0e\n\n', tol);
    
    fprintf('Iter\t  t_{n-1}\t  t_n\t\t  f(t_{n-1})\t  f(t_n)\t  Error\n');
    fprintf('----\t---------\t---------\t---------\t---------\t----------\n');
    
    % Call recursive function
    root = recursive_secant_core(f, x0, x1, tol, max_iter, 1);
    
    % Visualization
    figure;
    t_range = linspace(0, 5, 1000);
    plot(t_range, f(t_range), 'b-', 'LineWidth', 2);
    hold on;
    plot(root, 0, 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'red');
    plot([x0, x1], [f(x0), f(x1)], 'g--', 'LineWidth', 1);
    plot([0, 5], [0, 0], 'k--', 'LineWidth', 1);
    xlabel('Time t (seconds)');
    ylabel('Height h(t) (meters)');
    title('Recursive Secant Method: Projectile Motion');
    legend('h(t) = -4.9t² + 15t + 10', 'Root Found', 'Initial Secant', 'Location', 'northeast');
    grid on;
    
    fprintf('\nFinal root: t = %.8f seconds\n', root);
    fprintf('Final f(t) = %.2e\n', f(root));
end

function root = recursive_secant_core(f, x0, x1, tol, max_iter, current_iter)
    % Base case: maximum iterations reached
    if current_iter > max_iter
        root = x1;
        fprintf('Max iterations reached.\n');
        return;
    end
    
    f0 = f(x0);
    f1 = f(x1);
    
    % Check for division by zero
    if abs(f1 - f0) < 1e-12
        root = x1;
        fprintf('Function values too close. Stopping.\n');
        return;
    end
    
    % Secant update
    x2 = x1 - f1 * (x1 - x0) / (f1 - f0);
    error = abs(x2 - x1);
    
    fprintf('%3d\t%8.6f\t%8.6f\t%9.6f\t%9.6f\t%10.2e\n', ...
            current_iter, x0, x1, f0, f1, error);
    
    % Check convergence
    if abs(f1) < tol || error < tol
        root = x2;
        return;
    end
    
    % Recursive call
    root = recursive_secant_core(f, x1, x2, tol, max_iter, current_iter + 1);
end